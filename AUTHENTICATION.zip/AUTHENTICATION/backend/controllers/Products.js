import Products from "../models/ProductModel.js";

export const getProducts = (req, res) =>{

}

export const getProductById = (req, res) =>{
    
}

export const createProduct = (req, res) =>{
    
}

export const updateProduct = (req, res) =>{
    
}

export const deleteProduct = (req, res) =>{
    
}